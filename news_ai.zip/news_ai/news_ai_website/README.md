Credits:

News Source General Bias:
[1] https://mediabiasfactcheck.com/
[1.1] https://github.com/drmikecrowe/mbfcext/blob/master/mysql/csources.json
[1.2] https://raw.githubusercontent.com/drmikecrowe/mbfcext/master/mysql/csources.json