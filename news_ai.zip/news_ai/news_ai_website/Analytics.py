from collections import Counter
import datetime
import json


# sudo pip install python-dateutil --upgrade
bias_categories = ["right", "right-center", "left", "leftcenter", "center", "fake-news", "pro-science", "satire", "conspiracy"]


def xzyggy():

    # empty function for later stuff you might need

    return bias_categories


    
    